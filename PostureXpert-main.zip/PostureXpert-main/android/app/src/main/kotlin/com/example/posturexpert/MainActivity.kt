package com.example.posturexpert

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
