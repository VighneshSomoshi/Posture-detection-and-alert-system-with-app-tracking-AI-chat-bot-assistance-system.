import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DailyChallenge {
  final String challenge;
  final String description;
  final int durationInSeconds;

  DailyChallenge({required this.challenge, required this.description, required this.durationInSeconds});
}

class Daily extends StatelessWidget {
  final List<DailyChallenge> challenges = [
    DailyChallenge(challenge: "Morning Stretch", description: "Start your day with a full-body stretch to wake up your muscles and improve flexibility.", durationInSeconds: 300),
    DailyChallenge(challenge: "Posture Check", description: "Sit or stand with a straight spine and hold good posture for the given duration.", durationInSeconds: 600),
    DailyChallenge(challenge: "Neck Rolls", description: "Gently roll your neck in circular motions to release tension and improve mobility.", durationInSeconds: 180),
    DailyChallenge(challenge: "Seated Forward Bend", description: "A deep stretch to loosen up your hamstrings and lower back.", durationInSeconds: 300),
    DailyChallenge(challenge: "Cat-Cow Stretch", description: "A yoga pose to improve spinal flexibility and relieve back tension.", durationInSeconds: 300),
    DailyChallenge(challenge: "Child's Pose", description: "A resting yoga pose to stretch the lower back and relax the body.", durationInSeconds: 300),
    DailyChallenge(challenge: "Spinal Twist", description: "Gently twist your spine while seated to enhance flexibility and posture.", durationInSeconds: 300),
    DailyChallenge(challenge: "Wall Angels", description: "Stand against a wall and mimic angel wing movements to improve shoulder mobility.", durationInSeconds: 180),
    DailyChallenge(challenge: "Shoulder Shrugs", description: "Raise and lower your shoulders to release tension and strengthen the traps.", durationInSeconds: 180),
    DailyChallenge(challenge: "Standing Forward Bend", description: "Stretch your back and hamstrings by bending forward from a standing position.", durationInSeconds: 300),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Daily Challenges')),
      body: GridView.builder(
        padding: const EdgeInsets.all(10),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 1.5,
        ),
        itemCount: challenges.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ChallengeScreen(challenge: challenges[index]),
                ),
              );
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.blue,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: Text(
                  challenges[index].challenge,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}


class ChallengeScreen extends StatefulWidget {
  final DailyChallenge challenge;
  
  const ChallengeScreen({Key? key, required this.challenge}) : super(key: key);

  @override
  _ChallengeScreenState createState() => _ChallengeScreenState();
}

class _ChallengeScreenState extends State<ChallengeScreen> {
  late int remainingTime;
  Timer? timer;
  bool isStarted = false;

  @override
  void initState() {
    super.initState();
    remainingTime = widget.challenge.durationInSeconds;
  }

  void startChallenge() {
    setState(() {
      isStarted = true;
    });

    timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (remainingTime > 0) {
          remainingTime--;
        } else {
          timer.cancel();
          showCompletionDialog();
        }
      });
    });
  }

  void showCompletionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("🎉 Congratulations!"),
        content: const Text("You've successfully completed the challenge!"),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).pop();
            },
            child: const Text("OK", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF7EBCFB), Color(0xFF265BFB)],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                widget.challenge.challenge,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                widget.challenge.description,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 18, color: Colors.white70),
              ),
              const SizedBox(height: 30),
              Text(
                '⏳ Time Remaining: ${remainingTime ~/ 60}:${(remainingTime % 60).toString().padLeft(2, '0')}',
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: isStarted ? null : startChallenge,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  textStyle: const TextStyle(color:CupertinoColors.secondaryLabel , fontWeight: FontWeight.bold),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                  backgroundColor: Colors.white,
                  elevation: 10,
                  shadowColor: Colors.black54,
                ),
                child: Text(
                  isStarted ? "In Progress..." : "Start Challenge",
                  style: const TextStyle(color: Color.fromARGB(255, 0, 0, 0), fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
