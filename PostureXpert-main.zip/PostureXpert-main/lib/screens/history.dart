import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  DateTime? selectedDate;
  List<Map<String, dynamic>> postureData = [];

  /// Select Date Function
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        _fetchPostureData();
      });
    }
  }

  /// Fetch Data from Firestore
  Future<void> _fetchPostureData() async {
    if (selectedDate == null) return;

    String selectedDateString =
        "${selectedDate!.year.toString().padLeft(4, '0')}-${selectedDate!.month.toString().padLeft(2, '0')}-${selectedDate!.day.toString().padLeft(2, '0')}";

    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection('posture_data')
        .get(); // Fetch all, then filter locally

    setState(() {
      postureData = snapshot.docs.map((doc) {
        String dbDate = doc['date'].substring(0, 10); // Extract YYYY-MM-DD
        return {
          'date': dbDate,
          'duration': doc['duration'],
          'status': doc['status']
        };
      }).where((data) => data['date'] == selectedDateString).toList();
    });

    print("Selected Date: $selectedDateString");
    print("Filtered Data: $postureData");
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF7EBCFB),
            Color(0xFF265BFB),
          ],
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: const Text(
            'History',
            style: TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
          actions: [
            IconButton(
              icon: const Icon(Icons.notifications),
              color: Colors.white,
              iconSize: 30,
              onPressed: () {
                print('Notification icon pressed');
              },
            ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.only(top: 60),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  height: 550,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 10,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        GestureDetector(
                          onTap: () => _selectDate(context),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.calendar_today,
                                size: 24,
                                color: Colors.black,
                              ),
                              const SizedBox(width: 10),
                              Text(
                                selectedDate == null
                                    ? 'Select a Date'
                                    : '${selectedDate!.day}-${selectedDate!.month}-${selectedDate!.year}',
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 80),
                        if (selectedDate != null)
                          PosturePieChart(
                            postureData: postureData,
                            selectedDate: selectedDate!,
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class PosturePieChart extends StatelessWidget {
  final List<Map<String, dynamic>> postureData;
  final DateTime selectedDate;

  const PosturePieChart({
    required this.postureData,
    required this.selectedDate,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> filteredData = postureData.where((data) {
      return data['date'] ==
          "${selectedDate.year}-${selectedDate.month.toString().padLeft(2, '0')}-${selectedDate.day.toString().padLeft(2, '0')}";
    }).toList();

    double totalGoodMinutes = 0;
    double totalBadMinutes = 0;

    for (var entry in filteredData) {
      double durationInMinutes = entry['duration'] / 60; // Convert seconds to minutes

      if (entry['status'] == 'Good') {
        totalGoodMinutes += durationInMinutes;
      } else {
        totalBadMinutes += durationInMinutes;
      }
    }

    return SizedBox(
      height: 300,
      child: PieChart(
        PieChartData(
          sections: [
            PieChartSectionData(
              value: totalGoodMinutes,
              title: 'Good\n${totalGoodMinutes.toStringAsFixed(1)} Min',
              color: Colors.green,
              radius: 60,
            ),
            PieChartSectionData(
              value: totalBadMinutes,
              title: 'Bad\n${totalBadMinutes.toStringAsFixed(1)} Min',
              color: Colors.red,
              radius: 60,
            ),
          ],
        ),
      ),
    );
  }
}
