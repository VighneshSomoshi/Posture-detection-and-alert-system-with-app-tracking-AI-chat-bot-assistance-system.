import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class AiChatScreen extends StatefulWidget {
  const AiChatScreen({Key? key}) : super(key: key);

  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<AiChatScreen> {
  final List<Map<String, dynamic>> _questions = [
    {
      'question': 'Where do you feel pain?',
      'options': ['Lower back', 'Upper back', 'Neck', 'Whole back'],
    },
    {
      'question': 'How long have you had this pain?',
      'options': ['Less than a week', '1-3 weeks', 'More than a month'],
    },
    {
      'question': 'What worsens the pain?',
      'options': ['Standing', 'Sitting', 'Lifting weights', 'Lying down'],
    },
  ];

  int _currentQuestionIndex = 0;
  bool _showChat = false;
  bool _isTyping = false;
  final TextEditingController _messageController = TextEditingController();
  List<Map<String, String>> _chatMessages = [];

  void _nextQuestion(String answer) {
    _chatMessages.add({'user': answer});
    setState(() {
      _isTyping = true;
    });

    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        _chatMessages.add({'ai': _generateAnswer(answer)});
        _isTyping = false;
      });
    });

    if (_currentQuestionIndex < _questions.length - 1) {
      setState(() {
        _currentQuestionIndex++;
      });
    } else {
      setState(() {
        _showChat = true;
      });
    }
  }

  String _generateAnswer(String question) {
    Map<String, String> responses = {
      'Lower back': 'It could be muscle strain. Try some gentle stretching.',
      'Upper back': 'You may have posture-related tension. Maintain an ergonomic posture.',
      'Neck': 'Consider reducing screen time and using neck exercises.',
      'Whole back': 'If the pain is widespread, consult a specialist.',
      'Less than a week': 'It might be temporary. Rest and monitor your symptoms.',
      '1-3 weeks': 'Persistent pain should be checked by a doctor.',
      'More than a month': 'Long-term pain requires medical attention.',
      'Standing': 'Try using cushioned footwear and take breaks.',
      'Sitting': 'Ensure proper back support and take short walks.',
      'Lifting weights': 'Use proper form and avoid overexertion.',
      'Lying down': 'Consider changing your mattress or sleeping posture.',
    };
    return responses[question] ?? 'I recommend checking with a healthcare professional.';
  }
Future<String> _generateChatResponse(String message) async {
  try {
    const String apiKey = "Your_API"; // Replace with your actual key
    const String apiUrl = "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-pro:generateContent?key=$apiKey";

    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        "contents": [
          {
            "role": "user",
            "parts": [
              {"text": "$message. Please respond within 60 words."}
            ]
          }
        ]
      }),
    );

    print("API Response: ${response.body}");

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      String aiResponse = data['candidates'][0]['content']['parts'][0]['text'] ?? "I'm not sure how to respond.";
      
      // Ensure response is within 60 words
      List<String> words = aiResponse.split(' ');
      if (words.length > 60) {
        aiResponse = words.sublist(0, 60).join(' ') + "...";
      }

      return aiResponse;
    } else {
      return "Sorry, I couldn't fetch a response at the moment.";
    }
  } catch (e) {
    return "Error: Unable to connect to the AI service.";
  }
}


  void _sendMessage() async {
  String message = _messageController.text.trim();
  if (message.isEmpty) return;

  // List of greetings
  List<String> greetings = ['hi', 'hello', 'hey', 'good morning', 'good evening', 'good night'];

  // List of medical-related keywords
  List<String> medicalKeywords = [
    'pain', 'illness', 'disease', 'injury', 'symptom', 'medicine',
    'treatment', 'doctor', 'hospital', 'health', 'fever', 'infection',
    'inflammation', 'surgery', 'therapy', 'diagnosis', 'cancer', 'diabetes',
    'hypertension', 'flu', 'cold', 'headache', 'back pain', 'neck pain',
    'stomachache', 'migraine', 'bone fracture', 'muscle strain', 'arthritis'
  ];

  bool isGreeting = greetings.contains(message.toLowerCase());
  bool isMedicalQuery = medicalKeywords.any((keyword) => message.toLowerCase().contains(keyword));

  setState(() {
    _chatMessages.add({'user': message});
    _messageController.clear();
    _isTyping = true;
  });

  String aiResponse;

  if (isGreeting) {
    aiResponse = "Hello! How can I assist you today regarding medical concerns?";
  } else if (!isMedicalQuery) {
    aiResponse = "Please ask questions related to medical issues, pain, illness, or diseases.";
  } else {
    aiResponse = await _generateChatResponse(message);
  }

  setState(() {
    _chatMessages.add({'ai': aiResponse});
    _isTyping = false;
  });
}


  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF7EBCFB),
            Color(0xFF265BFB),
          ],
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: const Text(
            'AI Back Pain Doctor',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
        body: Column(
          children: [
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(20),
                itemCount: _chatMessages.length + (_isTyping ? 1 : 0),
                itemBuilder: (context, index) {
                  if (_isTyping && index == _chatMessages.length) {
                    return _buildTypingIndicator();
                  }
                  bool isUser = _chatMessages[index].containsKey('user');
                  return _buildChatBubble(
                      _chatMessages[index][isUser ? 'user' : 'ai']!, isUser);
                },
              ),
            ),
            _showChat ? _buildChatInput() : _buildQuestionScreen(),
          ],
        ),
      ),
    );
  }

  Widget _buildQuestionScreen() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _questions[_currentQuestionIndex]['question'],
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 20),
          ...(_questions[_currentQuestionIndex]['options'] as List<String>)
              .map((option) => GestureDetector(
                    onTap: () => _nextQuestion(option),
                    child: Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        option,
                        style: const TextStyle(fontSize: 18),
                      ),
                    ),
                  ))
              .toList(),
        ],
      ),
    );
  }

  Widget _buildChatBubble(String text, bool isUser) {
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.all(12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
        decoration: BoxDecoration(
          color: isUser ? Colors.blueAccent : Colors.white,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 16,
            color: isUser ? Colors.white : Colors.black,
          ),
        ),
      ),
    );
  }

  Widget _buildTypingIndicator() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Text('Typing...', style: TextStyle(fontSize: 16)),
      ),
    );
  }

  Widget _buildChatInput() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: const BoxDecoration(color: Colors.white),
      child: Row(
        children: [
          Expanded(child: TextField(controller: _messageController, decoration: const InputDecoration(hintText: 'Ask me anything...', border: InputBorder.none))),
          IconButton(icon: const Icon(Icons.send, color: Colors.blue), onPressed: _sendMessage),
        ],
      ),
    );
  }
}
