import 'dart:async';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:posturexpert/screens/ai.dart';
import 'package:posturexpert/screens/dailychallange.dart';
import 'package:posturexpert/screens/history.dart';
import 'package:posturexpert/screens/notification.dart';
import 'package:posturexpert/screens/progressbar.dart';
import 'package:posturexpert/screens/setting.dart';

class Bottomnavbar extends StatefulWidget {
  const Bottomnavbar({super.key});

  @override
  State<Bottomnavbar> createState() => _BottomnavbarState();
}

class _BottomnavbarState extends State<Bottomnavbar> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    const HomeScreen(),
    const HistoryScreen(),
    const ProfileScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: const Color.fromARGB(255, 95, 168, 227),
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'History'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}


class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final DatabaseReference _database =
      FirebaseDatabase.instance.ref("RealTimePostureData/Sensor1");

  DateTime? _sessionStartTime;
  String postureStatus = "Unknown";
  String lastStatus = "Unknown";
  Timer? _durationTimer;
  int durationInSeconds = 0;

  @override
  void initState() {
    super.initState();
    _sessionStartTime = DateTime.now();
    _startDurationTimer();
    _listenToRealTimeData();
  }

  void _startDurationTimer() {
    _durationTimer?.cancel();
    _durationTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        durationInSeconds = DateTime.now().difference(_sessionStartTime!).inSeconds;
      });
    });
  }

  void _listenToRealTimeData() {
    _database.onValue.listen((event) {
      if (event.snapshot.value != null) {
        Map<String, dynamic> data =
            Map<String, dynamic>.from(event.snapshot.value as Map);

        double pitch = double.tryParse(data["Pitch"].toString()) ?? 0;
        double roll = double.tryParse(
                data["Roll"].toString().replaceAll(RegExp(r'[^\d.]'), '')) ?? 0;
        String firebaseStatus = data["Status"].toString();

        print("Fetched Data -> Pitch: $pitch, Roll: $roll, Status: $firebaseStatus");

        String newStatus = (firebaseStatus == "Correct") ? "Good" : "Bad";

        if (newStatus != lastStatus) {
          // Save previous posture data before updating
          if (lastStatus != "Unknown") {
            _savePostureData(lastStatus, durationInSeconds, pitch, roll);
          }

          setState(() {
            postureStatus = newStatus;
            lastStatus = newStatus;
            _sessionStartTime = DateTime.now(); // Reset session start time
            durationInSeconds = 0; // Reset duration
          });
        }
      }
    });
  }

  Future<void> _savePostureData(String status, int duration, double pitch, double roll) async {
    DateTime now = DateTime.now();
    
    await _firestore.collection('posture_data').add({
      'status': status,
      'duration': duration,
      'pitch': pitch,
      'roll': roll,
      'date': now.toIso8601String(),
    });

    print("Data saved: Status = $status, Duration = $duration seconds, Pitch = $pitch, Roll = $roll");
  }

  @override
  void dispose() {
    _durationTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF7EBCFB), Color(0xFF265BFB)],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            AppBar(
              title: const Text(
                'PostureXpert',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              backgroundColor: Colors.transparent,
              elevation: 0,
              actions: [
                IconButton(
                  icon: const Icon(Icons.notifications),
                  color: Colors.white,
                  iconSize: 30,
                  onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const NotificationScreen()),
              );
            },
                ),
              ],
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    // Posture Status
                    Container(
                      margin: const EdgeInsets.only(top: 50),
                      height: 320,
                      width: 250,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 10,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset(
                            postureStatus == 'Good'
                                ? 'assets/images/goodpostures.jpg'
                                : 'assets/images/badposture.jpg',
                            height: 200,
                            width: 200,
                            fit: BoxFit.cover,
                          ),
                          const SizedBox(height: 20),
                          Text(
                            postureStatus == 'Good' ? 'Good Posture' : 'Bad Posture',
                            style: TextStyle(
                              color: postureStatus == 'Good'
                                  ? Color.fromARGB(255, 101, 170, 23)
                                  : Colors.red,
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 50,),
                      
                    
const RealTimeProgressWidget(),
                    
const SizedBox(height: 30,),
Column(
  mainAxisAlignment: MainAxisAlignment.end,
  children: [
    Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        // Daily Challenge Container with GestureDetector
        GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) =>  Daily()),
            );
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            width: 280,
            height: 60,
            margin: const EdgeInsets.only(left: 20, bottom: 20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 8,
                  spreadRadius: 3,
                ),
              ],
            ),
            alignment: Alignment.center,
            child: const Text(
              'Daily Challenge',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Colors.black87,
              ),
            ),
          ),
        ),

        // AI Chat Icon Button
        GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const AiChatScreen()),
            );
          },
          child: Container(
            width: 50,
            height: 60,
            margin: const EdgeInsets.only(right: 20, bottom: 20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 8,
                  spreadRadius: 3,
                ),
              ],
            ),
            child: const Icon(
              Icons.medical_information,
              color: Color.fromARGB(255, 95, 168, 227),
              size: 30,
            ),
          ),
        ),
      ],
    ),
  ],
),


                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
