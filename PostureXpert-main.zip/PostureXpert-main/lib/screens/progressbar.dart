import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class RealTimeProgressWidget extends StatefulWidget {
  const RealTimeProgressWidget({super.key});

  @override
  State<RealTimeProgressWidget> createState() => _RealTimeProgressWidgetState();
}

class _RealTimeProgressWidgetState extends State<RealTimeProgressWidget> {
  double pitch = 0.0;
  double roll = 0.0;

  @override
  void initState() {
    super.initState();
    _fetchRealTimeData();
  }

  void _fetchRealTimeData() {
    DatabaseReference ref = FirebaseDatabase.instance.ref('RealTimePostureData/Sensor1');

    ref.onValue.listen((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      if (data != null) {
        setState(() {
          pitch = double.tryParse(data['Pitch'].toString()) ?? 0.0;
          roll = double.tryParse(data['Roll'].toString().replaceAll('°', '')) ?? 0.0;
        });
      }
    });
  }

  Color getPitchColor() => pitch > 70 ? Colors.green : Colors.red;
  Color getRollColor() => roll < 30 ? Colors.green : Colors.red;

  Widget _buildProgressBar(String label, double value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
          const SizedBox(height: 5),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: value / 100,
              minHeight: 15,
              backgroundColor: const Color.fromARGB(255, 255, 255, 255),
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
          const SizedBox(height: 5),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              '${value.toStringAsFixed(2)}°',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _buildProgressBar('Back Angle (Pitch)', pitch, getPitchColor()),
          _buildProgressBar('Neck Angle (Roll)', roll, getRollColor()),
        ],
      ),
    );
  }
}
