import 'package:flutter/material.dart';
import 'dart:async';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  final DatabaseReference _database = FirebaseDatabase.instance.ref('posture');
  final DatabaseReference _notificationsRef = FirebaseDatabase.instance.ref('notifications');
  final FlutterLocalNotificationsPlugin _notificationsPlugin = FlutterLocalNotificationsPlugin();
  int badPostureCount = 0;
  Timer? _badPostureTimer;
  Timer? _averagePostureTimer;
  
  @override
  void initState() {
    super.initState();
    _initNotifications();
    _startListeningToPosture();
  }

  void _initNotifications() async {
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const InitializationSettings settings = InitializationSettings(android: androidSettings);
    await _notificationsPlugin.initialize(settings);
  }

  void _startListeningToPosture() {
    _database.onValue.listen((event) {
      final posture = event.snapshot.value as String?;
      if (posture == 'bad') {
        badPostureCount++;
      } else {
        badPostureCount = 0;
      }
      
      if (badPostureCount >= 60) {
        _sendNotification('Funny Alert!', 'Your posture is bad for 1 minute! Straighten up!');
        _storeNotification('Funny Alert!', 'Your posture is bad for 1 minute! Straighten up!');
        badPostureCount = 0;
      }
    });

    _averagePostureTimer = Timer.periodic(const Duration(hours: 4), (timer) {
      _sendNotification('Posture Check', 'You have been in average posture for 4 hours!');
      _storeNotification('Posture Check', 'You have been in average posture for 4 hours!');
    });
  }

  Future<void> _sendNotification(String title, String body) async {
    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'posture_channel',
      'Posture Notifications',
      importance: Importance.high,
      priority: Priority.high,
    );
    const NotificationDetails details = NotificationDetails(android: androidDetails);
    await _notificationsPlugin.show(0, title, body, details);
  }

  Future<void> _storeNotification(String title, String body) async {
    await _notificationsRef.push().set({
      'title': title,
      'body': body,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  @override
  void dispose() {
    _badPostureTimer?.cancel();
    _averagePostureTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Notifications',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      extendBodyBehindAppBar: true,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF7EBCFB),
              Color(0xFF265BFB),
            ],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Monitoring Posture...',
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
              
            ],
          ),
        ),
      ),
    );
  }
}